import { localizePtPT } from "./ptPt";
import React from "react";
import { Mail, ShieldCheck } from "lucide-react";

const content = {
  pt: {
    title: "Política de Privacidade",
    updated: "Última atualização: 15 de setembro de 2026",
    intro:
      "Esta política explica, de forma simples, quais dados o TraderTab utiliza e para quais finalidades.",
    collectedTitle: "Dados coletados",
    collected: [
      "Conta: e-mail, nome, foto e provedor de login fornecidos pelo Firebase Authentication.",
      "Perfil: data de nascimento, idade calculada, país e clube do coração opcional informados pelo usuário.",
      "Preferências: idioma, tema, consentimento de cookies, ordem das colunas, times, ligas e ranges favoritos.",
      "Jogos favoritos: dados da partida marcada pelo usuário, como data, horário, competição, times, posições e odds.",
      "Medição opcional: páginas visitadas, dispositivo, localização aproximada e interações com recursos, somente quando o usuário autoriza o Google Analytics.",
      "Publicidade: quando o AdSense estiver ativo, o Google e seus parceiros de publicidade poderão usar cookies, identificadores e sinais de consentimento para medir e veicular anúncios conforme as configurações aplicáveis.",
    ],
    purposeTitle: "Finalidades",
    purposes: [
      "Autenticar a conta e manter a sessão.",
      "Personalizar a experiência e salvar preferências.",
      "Liberar filtros, Race, reorganização de colunas, Meus Filtros e Meus Jogos para usuários autenticados.",
      "Entender o uso do site e melhorar o produto quando a medição for autorizada.",
      "Proteger o serviço e diagnosticar falhas.",
    ],
    providersTitle: "Serviços utilizados",
    providers:
      "Utilizamos Firebase Authentication e Cloud Firestore para conta, perfil e preferências; Google Analytics para medição opcional; Google AdSense para publicidade quando ativado; e Vercel para hospedagem do site.",
    passwordsTitle: "Senhas",
    passwords:
      "O TraderTab não armazena senhas. O cadastro, a validação, a recuperação e a sessão são processados pelo Firebase Authentication.",
    cookiesTitle: "Cookies e medição",
    cookies:
      "Cookies e armazenamentos necessários mantêm login e preferências. O Google Analytics só é ativado após autorização. Quando o AdSense estiver ativo, o consentimento de publicidade aplicável será gerenciado por uma plataforma de gestão de consentimento compatível com os requisitos do Google. As preferências disponíveis podem ser revistas pelo rodapé.",
    rightsTitle: "Solicitações sobre dados",
    rights:
      "Você pode solicitar acesso, correção ou exclusão de dados da sua conta pelo contato abaixo. Podemos pedir confirmação da identidade antes de atender à solicitação.",
    contactTitle: "Contato",
    contactText: "E-mail para assuntos de privacidade:",
  },
  en: {
    title: "Privacy Policy",
    updated: "Last updated: September 15, 2026",
    intro:
      "This policy explains, in simple terms, which data TraderTab uses and why.",
    collectedTitle: "Data collected",
    collected: [
      "Account: email, name, photo and login provider supplied by Firebase Authentication.",
      "Profile: date of birth, calculated age, country and optional favorite club entered by the user.",
      "Preferences: language, theme, cookie consent, column order, teams, leagues and favorite ranges.",
      "Favorite matches: match data starred by the user, such as date, time, competition, teams, positions and odds.",
      "Optional measurement: visited pages, device, approximate location and feature interactions, only when Google Analytics is authorized.",
      "Advertising: when AdSense is enabled, Google and its advertising partners may use cookies, identifiers and consent signals to measure and serve ads according to the applicable settings.",
    ],
    purposeTitle: "Purposes",
    purposes: [
      "Authenticate the account and maintain the session.",
      "Personalize the experience and save preferences.",
      "Unlock filters, Race, column reordering, My Filters and My Matches for authenticated users.",
      "Understand usage and improve the product when measurement is authorized.",
      "Protect the service and diagnose failures.",
    ],
    providersTitle: "Services used",
    providers:
      "We use Firebase Authentication and Cloud Firestore for accounts, profiles and preferences; Google Analytics for optional measurement; Google AdSense for advertising when enabled; and Vercel to host the website.",
    passwordsTitle: "Passwords",
    passwords:
      "TraderTab does not store passwords. Registration, validation, recovery and sessions are processed by Firebase Authentication.",
    cookiesTitle: "Cookies and measurement",
    cookies:
      "Essential cookies and storage keep login and preferences working. Google Analytics is enabled only after authorization. When AdSense is enabled, applicable advertising consent is managed through a consent management platform compatible with Google requirements. Available preferences can be reviewed from the footer.",
    rightsTitle: "Data requests",
    rights:
      "You may request access, correction or deletion of account data using the contact below. We may request identity confirmation before completing a request.",
    contactTitle: "Contact",
    contactText: "Privacy contact email:",
  },
  es: {
    title: "Política de Privacidad",
    updated: "Última actualización: 15 de septiembre de 2026",
    intro:
      "Esta política explica de forma sencilla qué datos utiliza TraderTab y para qué.",
    collectedTitle: "Datos recopilados",
    collected: [
      "Cuenta: correo, nombre, foto y proveedor de acceso suministrados por Firebase Authentication.",
      "Perfil: fecha de nacimiento, edad calculada, país y club favorito opcional informados por el usuario.",
      "Preferencias: idioma, tema, consentimiento de cookies, orden de columnas, equipos, ligas y rangos favoritos.",
      "Partidos favoritos: datos del partido marcado, como fecha, horario, competición, equipos, posiciones y cuotas.",
      "Medición opcional: páginas visitadas, dispositivo, ubicación aproximada e interacciones, solo cuando se autoriza Google Analytics.",
      "Publicidad: cuando AdSense esté activo, Google y sus socios publicitarios podrán usar cookies, identificadores y señales de consentimiento para medir y mostrar anuncios según la configuración aplicable.",
    ],
    purposeTitle: "Finalidades",
    purposes: [
      "Autenticar la cuenta y mantener la sesión.",
      "Personalizar la experiencia y guardar preferencias.",
      "Habilitar filtros, Race, reorganización de columnas, Mis Filtros y Mis Partidos.",
      "Entender el uso y mejorar el producto cuando se autoriza la medición.",
      "Proteger el servicio y diagnosticar fallos.",
    ],
    providersTitle: "Servicios utilizados",
    providers:
      "Utilizamos Firebase Authentication y Cloud Firestore para cuentas, perfiles y preferencias; Google Analytics para medición opcional; y Vercel para alojar el sitio.",
    passwordsTitle: "Contraseñas",
    passwords:
      "TraderTab no almacena contraseñas. El registro, validación, recuperación y sesión son procesados por Firebase Authentication.",
    cookiesTitle: "Cookies y medición",
    cookies:
      "Las cookies y almacenamientos necesarios mantienen el acceso y las preferencias. Google Analytics solo se activa tras autorización. Cuando AdSense esté activo, el consentimiento publicitario aplicable se gestionará mediante una plataforma de gestión de consentimiento compatible con los requisitos de Google. Las preferencias disponibles pueden revisarse desde el pie de página.",
    rightsTitle: "Solicitudes de datos",
    rights:
      "Puedes solicitar acceso, corrección o eliminación de datos usando el contacto siguiente. Podemos pedir confirmación de identidad.",
    contactTitle: "Contacto",
    contactText: "Correo para asuntos de privacidad:",
  },
};

content["pt-PT"] = localizePtPT(content.pt);

export default function PrivacyPolicy({ language }) {
  const t = content[language] || content.pt;

  return (
    <main className="privacy-page">
      <div className="privacy-shell">
        <header className="privacy-header">
          <span>
            <ShieldCheck size={28} />
          </span>
          <div>
            <small>TraderTab</small>
            <h1>{t.title}</h1>
            <p>{t.updated}</p>
          </div>
        </header>

        <p className="privacy-intro">{t.intro}</p>

        <section>
          <h2>{t.collectedTitle}</h2>
          <ul>{t.collected.map((item) => <li key={item}>{item}</li>)}</ul>
        </section>

        <section>
          <h2>{t.purposeTitle}</h2>
          <ul>{t.purposes.map((item) => <li key={item}>{item}</li>)}</ul>
        </section>

        <section>
          <h2>{t.providersTitle}</h2>
          <p>{t.providers}</p>
        </section>

        <section>
          <h2>{t.passwordsTitle}</h2>
          <p>{t.passwords}</p>
        </section>

        <section>
          <h2>{t.cookiesTitle}</h2>
          <p>{t.cookies}</p>
        </section>

        <section>
          <h2>{t.rightsTitle}</h2>
          <p>{t.rights}</p>
        </section>

        <section className="privacy-contact">
          <Mail size={20} />
          <div>
            <h2>{t.contactTitle}</h2>
            <p>{t.contactText}</p>
            <a href="mailto:myradardev@gmail.com">myradardev@gmail.com</a>
          </div>
        </section>
      </div>
    </main>
  );
}
